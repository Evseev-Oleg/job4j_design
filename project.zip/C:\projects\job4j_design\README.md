# job4j_design
[![Build Status](https://travis-ci.org/Evseev-Oleg/job4j_design.svg?branch=master)](https://travis-ci.org/Evseev-Oleg/job4j_design)
[![codecov](https://codecov.io/gh/Evseev-Oleg/job4j_design/branch/master/graph/badge.svg?token=MY4T6OY5FJ)](https://codecov.io/gh/Evseev-Oleg/job4j_design)